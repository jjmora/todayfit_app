import React from 'react'

const FranchisesComponent = (props) => {
  return (
    <div>Franchises Component {props.variable}</div>
  )
}

export default FranchisesComponent