import React, { useEffect, useState } from "react";
import axios from "axios";
import Card from "./Card";
import Pagination from "./Pagination";

const Franchises = () => {
  const [franchisesArray, setFranchisesArray] = useState();
  const [filteredFranchises, setFilteredFranchises] = useState();
  const [inputValue, setInputValue] = useState("");
  const [activeState, setActiveState] = useState("all");
  const [errorOnLoading, setErrorOnLoading] = useState();
  //Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const [postsPerPage, setPostsPerPage] = useState(6);
  const [filteredItemsQty, setFilteredItemsQty] = useState(100);

  // const baseUrl = 'http://localhost:8000'
  // const currBaseUrl = window.location.href

  let dataByInput;
  let dataByActiveState;

  const lastPostIndex = currentPage * postsPerPage; // 1 * 6 = 6
  const firstPostIndex = lastPostIndex - postsPerPage; // 6 - 6 = 0

  // Load Data at document loading
  useEffect(() => {
    axios
      .get(`/franchise/franchise_json`)
      .then((response) => {
        //console.log("Initial Data: ", response.data);
        setFranchisesArray(response.data.franchisesArray);
        setFilteredFranchises(
          response.data.franchisesArray.slice(firstPostIndex, lastPostIndex)
        );
        setFilteredItemsQty(response.data.franchisesArray.length);
        setErrorOnLoading();
      })
      .catch((error) => {
        //console.log(error);
        setErrorOnLoading("Une erreur c'est produite");
      });
  }, []);

  const handleFilterClick = (e) => {
    setActiveState(e.target.id);
    // give CSS classes for formatting
    let parent = e.currentTarget.parentElement;
    //console.log(parent);
    let children = parent.children;
    //console.log(children);
    for (let child of children) {
      child.classList.remove("filter-active");
    }
    e.target.classList.add("filter-active");
  };

  const handleInputField = (e) => {
    setInputValue(e.target.value);
  };

  useEffect(() => {
    console.log("FilteredFranchises: ", filteredFranchises);
    // Filter dat by User Input - by inputValue

    if (inputValue) {
      let lowerCaseInputValue = inputValue.toLowerCase()
      dataByInput = franchisesArray?.filter((fr, k) => {
        let email = fr.email
        email = email.toLowerCase()
        let email_perso = fr.email_perso
        email_perso = email_perso.toLowerCase()
        let name = fr.name
        name = name.toLowerCase()
        return (
          fr.email.includes(lowerCaseInputValue) ||
          fr.email_perso.includes(lowerCaseInputValue) ||
          fr.name.includes(lowerCaseInputValue)
        );
      });
    } else {
      dataByInput = franchisesArray;
    }
    console.log("Data by input:", dataByInput);
    console.log("FranchiseArray:", franchisesArray);

    // by activeState
    if (activeState === "active") {
      dataByActiveState = dataByInput?.filter((fr, k) => {
        return fr.isActive === true;
      });
      console.log("X :", dataByActiveState);
      console.log("X :", dataByActiveState?.length);

      setFilteredItemsQty(dataByActiveState?.length);
    } else if (activeState === "non-active") {
      dataByActiveState = dataByInput?.filter((fr, k) => {
        return fr.isActive === false;
      });
      console.log("X :", dataByActiveState?.length);

      setFilteredItemsQty(dataByActiveState?.length);
    } else {
      dataByActiveState = dataByInput;
      console.log("X :", dataByActiveState?.length);

      setFilteredItemsQty(dataByActiveState?.length);
    }

    console.log("firstPostIndex: ", firstPostIndex);
    console.log("firstPostIndex: ", lastPostIndex);
    let currentPosts = dataByActiveState
    if (dataByActiveState?.length > 6) {
      currentPosts = dataByActiveState?.slice(firstPostIndex, lastPostIndex);
    }
    console.log("CurrentPosts:", currentPosts);

    //setFilteredFranchises(currData);
    setFilteredFranchises(currentPosts);
    //setFilteredFranchises(dataByActiveState)
  }, [activeState, inputValue, currentPage]);

  return (
    <>
      <div>
        <ul className="d-flex flex-row justify-content-center active-filter">
          <li onClick={handleFilterClick} className="filter-active" id="all">
            Tout
          </li>
          <li onClick={handleFilterClick} className="" id="active">
            Active
          </li>
          <li onClick={handleFilterClick} className="" id="non-active">
            Non Active
          </li>
        </ul>
      </div>

      <div className="input-group mb-3">
        <input
          id="form-input"
          type="search"
          className="form-control"
          placeholder="Entrez le(s) mot(s) clé(s)..."
          aria-label="Username"
          aria-describedby="basic-addon1"
          onChange={handleInputField}
        />
        <span
          className="input-group-text bg-primary text-white"
          id="basic-addon1"
        >
          <i className="bi bi-search"></i>
        </span>
      </div>
      <div>
        <p>{errorOnLoading}</p>
      </div>
      <section>
        <div className="row row-cols-1 row-cols-md-2 row-cols-xl-3 g-4">
          {filteredFranchises?.map((franchise, key) => {
            return (
              <Card
                key={key}
                franchiseId={franchise.id}
                franchiseName={franchise.name}
                franchiseEmail={franchise.email}
                franchiseEmailPerso={franchise.email_perso}
                permissions={franchise.permissions}
                franchiseDate={franchise.date}
                franchiseIsActive={franchise.isActive}
                franchiseImage={franchise.image}
                franchiseDescription={franchise.description}
              />
            );
          })}
        </div>
      </section>
      <nav className="pagination-section d-flex justify-content-center">
        {filteredItemsQty > 6 ? (
          <Pagination
            totalPosts={franchisesArray?.length}
            postsPerPage={postsPerPage}
            setCurrentPage={setCurrentPage}
            currentPage={currentPage}
          />
        ) : (
          ""
        )}
      </nav>
    </>
  );
};

export default Franchises;
